#!/bin/sh

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:%teamcity.tool.psql-9.2%/lib64;%teamcity.tool.psql-9.2%/bin/psql
