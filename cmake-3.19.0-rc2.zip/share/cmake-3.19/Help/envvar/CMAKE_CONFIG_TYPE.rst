CMAKE_CONFIG_TYPE
-----------------

.. versionadded:: 3.10

.. include:: ENV_VAR.txt

The default build configuration for :ref:`Build Tool Mode` and
``ctest`` build handler when there is no explicit configuration given.
