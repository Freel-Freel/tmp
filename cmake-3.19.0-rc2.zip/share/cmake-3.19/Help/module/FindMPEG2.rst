.. cmake-module:: ../../Modules/FindMPEG2.cmake
