.. cmake-module:: ../../Modules/FindPackageMessage.cmake
